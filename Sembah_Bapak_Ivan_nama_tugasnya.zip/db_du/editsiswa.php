<?php
include_once("koneksi.php");
if (isset($_POST['update'])) {
    $kd_siswa = $_POST['kd_siswa'];

    $nis = $_POST['nis'];
    $nama_siswa = $_POST['nama_siswa'];
    $jenkel = $_POST['jenkel'];
    $agama = $_POST['agama'];
    $tempat_lahir = $_POST['tempat_lahir'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
     $alamat = $_POST['alamat'];
      $no_telp= $_POST['no_telp'];
       $foto = $_POST['foto'];
        $tahun_angkatan = $_POST['tahun_angkatan'];
         $status = $_POST['status'];

    // update user data
    $ambildata = mysqli_query($koneksi, "UPDATE tb_siswa SET nis='$nis',nama_siswa='$nama_siswa',jenkel='$jenkel',agama='$agama',tempat_lahir='$tempat_lahir',tanggal_lahir='$tanggal_lahir',alamat='$alamat',no_telp='$no_telp',foto='$foto',tahun_angkatan='$tahun_angkatan',status='$status' WHERE kd_guru=$kd_guru");


    header("Location: showsiswa.php");
}
?>
<?php

$kd_siswa = $_GET['kode'];


$ambildata  = mysqli_query($koneksi, "SELECT * FROM tb_siswa WHERE kd_siswa=$kd_siswa");

while ($user_data = mysqli_fetch_array($ambildata)) {
    $nis = $user_data['nis'];
    $nama_siswa= $user_data['nama_siswa'];
    $jenkel = $user_data['jenkel'];
    $agama= $user_data['agama'];
    $tempat_lahir = $user_data['tempat_lahir'];
    $tanggal_lahir = $user_data['tanggal_lahir'];
    $alamat= $user_data['alamat'];
    $no_telp = $user_data['no_telp'];
    $foto = $user_data['foto'];
    $tahun_angkatan = $user_data['tahun_angkatan'];
    $status= $user_data['status'];
}
?>
<html>

<head>
    <title>Edit User Data</title>
</head>

<body>
    <a href="showsiswa.php">Home</a>
    <br /><br />

    <form name="update_user" method="post" action="editsiswa.php">
        <table border="0">
            <tr>
                <td>NIS</td>
                <td><input type="text" name="nis" value=<?php echo $nis; ?>></td>
            </tr>
            <tr>
                <td>Nama siswa</td>
                <td><input type="text" name="nama_siswa" value=<?php echo $nama_siswa; ?>></td>
            </tr>
            <tr>
                <td>Jenkel</td>
                <td><input type="text" name="jenkel" value=<?php echo $jenkel; ?>></td>
            </tr>
            <tr>
                <td>agama</td>
                <td><input type="text" name="agama" value=<?php echo $agama; ?>>
                </td>
            </tr>
             <tr>
                <td>Tempat Lahir</td>
                <td><input type="text" name="tempat_lahir" value=<?php echo $tempat_lahir; ?>>
                </td>
            </tr>
             <tr>
                <td>Tanggal_lahir</td>
                <td><input type="text" name="tanggal_lahir" value=<?php echo $tanggal_lahir; ?>>
                </td>
            </tr>
            <tr>
                <td>alamat</td>
                <td><input type="text" name="alamat" value=<?php echo $alamat; ?>></td>
            </tr>

            <tr>
                <td>no_telp</td>
                <td><input type="text" name="no_telp" value=<?php echo $no_telp; ?>></td>
            </tr>
             <tr>
                <td>Foto</td>
                <td><input type="text" name="foto" value=<?php echo $foto; ?>>
                </td>
            </tr>
             <tr>
                <td>tahun_angatan</td>
                <td><input type="text" name="tahun_angkatan" value=<?php echo $tahun_angkatan; ?>>
                </td>
            </tr>
             <tr>
                <td>status</td>
                <td><input type="text" name="status" value=<?php echo $status; ?>>
                </td>
            </tr>
            <tr>
                <td><input type="hidden" name="kd_siswa" value=<?php echo $_GET['kode']; ?>>
                </td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>
</body>

</html>