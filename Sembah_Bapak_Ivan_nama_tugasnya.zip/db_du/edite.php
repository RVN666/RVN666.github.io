<?php
include_once("koneksi.php");
if (isset($_POST['update'])) {
    $kd_guru = $_POST['kd_guru'];

    $nip = $_POST['nip'];
    $nama_guru = $_POST['nama_guru'];
    $jenkel = $_POST['jenkel'];
    $alamat = $_POST['alamat'];
    $no_telpon = $_POST['no_telpon'];
    $status_aktif = $_POST['status_aktif'];

    // update user data
    $ambildata = mysqli_query($koneksi, "UPDATE tb_guru SET nip='$nip',nama_guru='$nama_guru',jenkel='$jenkel',alamat='$alamat',no_telpon='$no_telpon',status_aktif='$status_aktif' WHERE kd_guru=$kd_guru");


    header("Location: tampan.php");
}
?>
<?php

$kd_guru = $_GET['kode'];


$ambildata  = mysqli_query($koneksi, "SELECT * FROM tb_guru WHERE kd_guru=$kd_guru");

while ($user_data = mysqli_fetch_array($ambildata)) {
    $nip = $user_data['nip'];
    $nama_guru = $user_data['nama_guru'];
    $jenkel = $user_data['jenkel'];
    $alamat = $user_data['alamat'];
    $no_telpon = $user_data['no_telpon'];
    $status_aktif = $user_data['status_aktif'];
}
?>
<html>

<head>
    <title>Edit User Data</title>
</head>

<body>
    <a href="tampan.php">Home</a>
    <br /><br />

    <form name="update_user" method="post" action="edite.php">
        <table border="0">
            <tr>
                <td>NIP</td>
                <td><input type="text" name="nip" value=<?php echo $nip; ?>></td>
            </tr>
            <tr>
                <td>Nama Dosen</td>
                <td><input type="text" name="nama_guru" value=<?php echo $nama_guru; ?>></td>
            </tr>
            <tr>
                <td>Jenkel</td>
                <td><input type="text" name="jenkel" value=<?php echo $jenkel; ?>></td>
            </tr>
            <tr>
                <td>alamat</td>
                <td><input type="text" name="alamat" value=<?php echo $alamat; ?>></td>
            </tr>
            <tr>
                <td>No Telepon</td>
                <td><input type="text" name="no_telpon" value=<?php echo $no_telpon; ?>></td>
            </tr>
            <tr>
                <td>Status Aktif</td>
                <td><input type="text" name="status_aktif" value=<?php echo $status_aktif; ?>>
                </td>
            </tr>
            <tr>
                <td><input type="hidden" name="kd_guru" value=<?php echo $_GET['kode']; ?>>
                </td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>
</body>

</html>