<!DOCTYPE html>
<html lang="en">
<head>
    <title>Index</title>
    <link rel="stylesheet" href="as.css">
</head>
<body>
    <?php
 session_start();

 // cek apakah yang mengakses halaman ini sudah login
 if($_SESSION['level']==""){
  header("location:index.php?pesan=gagal");
 }

 ?>
 

 
    <nav>
        <div class="wrapper">
            <div class="logo"><a href=''>Halaman Utama Kaprodi</a></div>
            <div class="menu">

                <ul>
                    <li><a href="#Home">Home</a></li>
                    <li><a href=http://localhost/db_du/input_guru.html>Input_Dosen</a></li>
                    <li><a href=http://localhost/db_du/inputsiswa.html>Input Mahasiswa</a></li>
                    <li><a href=http://localhost/db_du/tampilguru.php>Tampil Data Dosen</a></li>
                    <li><a href=http://localhost/db_du/tampilsiswa.php>Tampil Data Mahasiswa</a></li>
                    <li><a href="" class="tbl-biru">Sign Up</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="wrapper">
        <section id="home">
            <div class="kolom">
                <p>Halo <b><?php echo $_SESSION['username']; ?></b> Anda telah login sebagai <b><?php echo $_SESSION['level']; ?></b>.</p>
 
                <p class="deskripsi">SIAKAD SMK Islam 1 Durenan</p>
                <h2>Selamat Datang Di Website SMK Islam 1 Durenan</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laudantium asperiores voluptate assumenda! Expedita, quidem. Porro provident excepturi minima molestias id corrupti veniam totam officia ipsam unde! Repellendus officiis enim illo.</p>
                <p><a href=""</a>
                    <a href="logout.php">LOGOUT</a></p>
            </div>
        </section>
    </div>
</body>
</html>