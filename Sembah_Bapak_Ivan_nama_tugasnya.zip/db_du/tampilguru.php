<h1>INI ADALAH HALAMAN TAMPIL DATA DOSEN</h1>
<?php
session_start();

 // cek apakah yang mengakses halaman ini sudah login
 if($_SESSION['level']==""){
  header("location:index.php?pesan=gagal");
 }

 ?>

 <p>Halo <b><?php echo $_SESSION['username']; ?></b> Anda telah login sebagai <b><?php echo $_SESSION['level']; ?></b>.</p>
 <a href="logout.php">LOGOUT</a>

 <br/>
 <br/>
 <?php
include 'koneksi.php';
$sql = 'SELECT kd_guru,nip,nama_guru,jenkel,alamat 
        FROM tb_guru';
        
$query = mysqli_query($koneksi, $sql);

if (!$query) {
    die ('SQL Error: ' . mysqli_error($koneksi));
}  
echo "<table>
        <thead>
            <tr>
                <th>kd_guru</th>
                <th>nip</th>
                <th>nama_guru</th>
                <th>jenkel</th>
                <th>alamat</th>
            </tr>
        </thead>
        <body>";
        
while ($row = mysqli_fetch_array($query))
{
    echo '<tr>
            <td>'.$row['kd_guru'].'</td>
            <td>'.$row['nip'].'</td>
            <td>'.($row['nama_guru']).'</td>
            <td>'.$row['jenkel'].'</td>
            <td>'.$row['alamat'].'</td>
        </tr>';
}
echo '
    </body>
</table>';
mysqli_free_result($query);
mysqli_close($koneksi)
?>