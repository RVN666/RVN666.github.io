<?php
<form action="tamppil_data_guru"method ="post"name="postform">
<p align="center"><font color="orange" size="3"><b>Form Tampil Data</b></font></p>
    <table border="0">
        <tr>
            <td colspan="2" width="190"><input type="submit" value="Tampilkan Data" name="tampil"/></td>
        </tr>
    </table>
    </form>
?>