<h3><a href="input_guru.html">Tambah </a></h3>
<table border="1">
    <tr>
        <th>KODE DOSEN</th>
        <th>NIP </th>
        <th>NAMA DOSEN </th>
        <th>JENKEL</th>
        <th>ALAMAT</th>
        <th>No_Telp</th>
        <th>Status</th>
        <th colspan="2">Aksi</th>
    </tr>

    <?php
    include "koneksi.php";

    $no = 1;
    $ambildata = mysqli_query($koneksi, "select * from tb_guru");
    while ($tampil = mysqli_fetch_array($ambildata)) {
        echo "
        <tr>
            <td>$tampil[kd_guru]</td>
            <td>$tampil[nip]</td>
            <td>$tampil[nama_guru]</td>
            <td>$tampil[jenkel]</td>
            <td>$tampil[alamat]</td>
            <td>$tampil[no_telpon]</td>
            <td>$tampil[status_aktif]</td>
            <td><a href='delete.php?kode=$tampil[kd_guru]'> Hapus </a></td>
            <td><a href='edite.php?kode=$tampil[kd_guru]'> Ubah </a></td>
        <tr>";
        $no++;
    }
    ?>
</table>
<a href=halaman_utama_admin.php>Back To Home</a>